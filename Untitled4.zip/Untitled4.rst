
.. code:: ipython3

    3+4




.. parsed-literal::

    7



.. code:: ipython3

    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    

.. code:: ipython3

    dataframe=pd.read_csv('FuelConsumption.csv')
    dataframe




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>MODELYEAR</th>
          <th>MAKE</th>
          <th>MODEL</th>
          <th>VEHICLECLASS</th>
          <th>ENGINESIZE</th>
          <th>CYLINDERS</th>
          <th>TRANSMISSION</th>
          <th>FUELTYPE</th>
          <th>FUELCONSUMPTION_CITY</th>
          <th>FUELCONSUMPTION_HWY</th>
          <th>FUELCONSUMPTION_COMB</th>
          <th>FUELCONSUMPTION_COMB_MPG</th>
          <th>CO2EMISSIONS</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS5</td>
          <td>Z</td>
          <td>9.9</td>
          <td>6.7</td>
          <td>8.5</td>
          <td>33</td>
          <td>196</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX</td>
          <td>COMPACT</td>
          <td>2.4</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>11.2</td>
          <td>7.7</td>
          <td>9.6</td>
          <td>29</td>
          <td>221</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX HYBRID</td>
          <td>COMPACT</td>
          <td>1.5</td>
          <td>4</td>
          <td>AV7</td>
          <td>Z</td>
          <td>6.0</td>
          <td>5.8</td>
          <td>5.9</td>
          <td>48</td>
          <td>136</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>MDX 4WD</td>
          <td>SUV - SMALL</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>12.7</td>
          <td>9.1</td>
          <td>11.1</td>
          <td>25</td>
          <td>255</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>RDX AWD</td>
          <td>SUV - SMALL</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>12.1</td>
          <td>8.7</td>
          <td>10.6</td>
          <td>27</td>
          <td>244</td>
        </tr>
        <tr>
          <th>5</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>RLX</td>
          <td>MID-SIZE</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>11.9</td>
          <td>7.7</td>
          <td>10.0</td>
          <td>28</td>
          <td>230</td>
        </tr>
        <tr>
          <th>6</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TL</td>
          <td>MID-SIZE</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>11.8</td>
          <td>8.1</td>
          <td>10.1</td>
          <td>28</td>
          <td>232</td>
        </tr>
        <tr>
          <th>7</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TL AWD</td>
          <td>MID-SIZE</td>
          <td>3.7</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>12.8</td>
          <td>9.0</td>
          <td>11.1</td>
          <td>25</td>
          <td>255</td>
        </tr>
        <tr>
          <th>8</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TL AWD</td>
          <td>MID-SIZE</td>
          <td>3.7</td>
          <td>6</td>
          <td>M6</td>
          <td>Z</td>
          <td>13.4</td>
          <td>9.5</td>
          <td>11.6</td>
          <td>24</td>
          <td>267</td>
        </tr>
        <tr>
          <th>9</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TSX</td>
          <td>COMPACT</td>
          <td>2.4</td>
          <td>4</td>
          <td>AS5</td>
          <td>Z</td>
          <td>10.6</td>
          <td>7.5</td>
          <td>9.2</td>
          <td>31</td>
          <td>212</td>
        </tr>
        <tr>
          <th>10</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TSX</td>
          <td>COMPACT</td>
          <td>2.4</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>11.2</td>
          <td>8.1</td>
          <td>9.8</td>
          <td>29</td>
          <td>225</td>
        </tr>
        <tr>
          <th>11</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>TSX</td>
          <td>COMPACT</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS5</td>
          <td>Z</td>
          <td>12.1</td>
          <td>8.3</td>
          <td>10.4</td>
          <td>27</td>
          <td>239</td>
        </tr>
        <tr>
          <th>12</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>DB9</td>
          <td>MINICOMPACT</td>
          <td>5.9</td>
          <td>12</td>
          <td>A6</td>
          <td>Z</td>
          <td>18.0</td>
          <td>12.6</td>
          <td>15.6</td>
          <td>18</td>
          <td>359</td>
        </tr>
        <tr>
          <th>13</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>RAPIDE</td>
          <td>SUBCOMPACT</td>
          <td>5.9</td>
          <td>12</td>
          <td>A6</td>
          <td>Z</td>
          <td>18.0</td>
          <td>12.6</td>
          <td>15.6</td>
          <td>18</td>
          <td>359</td>
        </tr>
        <tr>
          <th>14</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>V8 VANTAGE</td>
          <td>TWO-SEATER</td>
          <td>4.7</td>
          <td>8</td>
          <td>AM7</td>
          <td>Z</td>
          <td>17.4</td>
          <td>11.3</td>
          <td>14.7</td>
          <td>19</td>
          <td>338</td>
        </tr>
        <tr>
          <th>15</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>V8 VANTAGE</td>
          <td>TWO-SEATER</td>
          <td>4.7</td>
          <td>8</td>
          <td>M6</td>
          <td>Z</td>
          <td>18.1</td>
          <td>12.2</td>
          <td>15.4</td>
          <td>18</td>
          <td>354</td>
        </tr>
        <tr>
          <th>16</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>V8 VANTAGE S</td>
          <td>TWO-SEATER</td>
          <td>4.7</td>
          <td>8</td>
          <td>AM7</td>
          <td>Z</td>
          <td>17.4</td>
          <td>11.3</td>
          <td>14.7</td>
          <td>19</td>
          <td>338</td>
        </tr>
        <tr>
          <th>17</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>V8 VANTAGE S</td>
          <td>TWO-SEATER</td>
          <td>4.7</td>
          <td>8</td>
          <td>M6</td>
          <td>Z</td>
          <td>18.1</td>
          <td>12.2</td>
          <td>15.4</td>
          <td>18</td>
          <td>354</td>
        </tr>
        <tr>
          <th>18</th>
          <td>2014</td>
          <td>ASTON MARTIN</td>
          <td>VANQUISH</td>
          <td>MINICOMPACT</td>
          <td>5.9</td>
          <td>12</td>
          <td>A6</td>
          <td>Z</td>
          <td>18.0</td>
          <td>12.6</td>
          <td>15.6</td>
          <td>18</td>
          <td>359</td>
        </tr>
        <tr>
          <th>19</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A4</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AV8</td>
          <td>Z</td>
          <td>9.9</td>
          <td>7.4</td>
          <td>8.8</td>
          <td>32</td>
          <td>202</td>
        </tr>
        <tr>
          <th>20</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A4 QUATTRO</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS8</td>
          <td>Z</td>
          <td>11.5</td>
          <td>8.1</td>
          <td>10.0</td>
          <td>28</td>
          <td>230</td>
        </tr>
        <tr>
          <th>21</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A4 QUATTRO</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>10.8</td>
          <td>7.5</td>
          <td>9.3</td>
          <td>30</td>
          <td>214</td>
        </tr>
        <tr>
          <th>22</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A5 CABRIOLET QUATTRO</td>
          <td>SUBCOMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS8</td>
          <td>Z</td>
          <td>11.5</td>
          <td>8.1</td>
          <td>10.0</td>
          <td>28</td>
          <td>230</td>
        </tr>
        <tr>
          <th>23</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A5 QUATTRO</td>
          <td>SUBCOMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS8</td>
          <td>Z</td>
          <td>11.5</td>
          <td>8.1</td>
          <td>10.0</td>
          <td>28</td>
          <td>230</td>
        </tr>
        <tr>
          <th>24</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A5 QUATTRO</td>
          <td>SUBCOMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>10.8</td>
          <td>7.5</td>
          <td>9.3</td>
          <td>30</td>
          <td>214</td>
        </tr>
        <tr>
          <th>25</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A6 QUATTRO</td>
          <td>MID-SIZE</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS8</td>
          <td>Z</td>
          <td>12.0</td>
          <td>8.1</td>
          <td>10.2</td>
          <td>28</td>
          <td>235</td>
        </tr>
        <tr>
          <th>26</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A6 QUATTRO</td>
          <td>MID-SIZE</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS8</td>
          <td>Z</td>
          <td>12.8</td>
          <td>8.6</td>
          <td>10.9</td>
          <td>26</td>
          <td>251</td>
        </tr>
        <tr>
          <th>27</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A6 QUATTRO TDI CLEAN DIESEL</td>
          <td>MID-SIZE</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS8</td>
          <td>D</td>
          <td>9.8</td>
          <td>6.4</td>
          <td>8.3</td>
          <td>34</td>
          <td>224</td>
        </tr>
        <tr>
          <th>28</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A7 QUATTRO</td>
          <td>MID-SIZE</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS8</td>
          <td>Z</td>
          <td>13.1</td>
          <td>8.8</td>
          <td>11.2</td>
          <td>25</td>
          <td>258</td>
        </tr>
        <tr>
          <th>29</th>
          <td>2014</td>
          <td>AUDI</td>
          <td>A7 QUATTRO TDI CLEAN DIESEL</td>
          <td>MID-SIZE</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS8</td>
          <td>D</td>
          <td>9.8</td>
          <td>6.4</td>
          <td>8.3</td>
          <td>34</td>
          <td>224</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>1037</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>M5</td>
          <td>X</td>
          <td>10.4</td>
          <td>7.2</td>
          <td>9.0</td>
          <td>31</td>
          <td>207</td>
        </tr>
        <tr>
          <th>1038</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA GLI</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>A6</td>
          <td>Z</td>
          <td>10.2</td>
          <td>7.5</td>
          <td>9.0</td>
          <td>31</td>
          <td>207</td>
        </tr>
        <tr>
          <th>1039</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA GLI</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>10.6</td>
          <td>7.4</td>
          <td>9.2</td>
          <td>31</td>
          <td>212</td>
        </tr>
        <tr>
          <th>1040</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA TDI CLEAN DIESEL</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>A6</td>
          <td>D</td>
          <td>7.9</td>
          <td>5.7</td>
          <td>6.9</td>
          <td>41</td>
          <td>186</td>
        </tr>
        <tr>
          <th>1041</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA TDI CLEAN DIESEL</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>D</td>
          <td>7.9</td>
          <td>5.6</td>
          <td>6.9</td>
          <td>41</td>
          <td>186</td>
        </tr>
        <tr>
          <th>1042</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>JETTA TURBO HYBRID</td>
          <td>COMPACT</td>
          <td>1.4</td>
          <td>4</td>
          <td>AM7</td>
          <td>Z</td>
          <td>5.6</td>
          <td>5.2</td>
          <td>5.4</td>
          <td>52</td>
          <td>124</td>
        </tr>
        <tr>
          <th>1043</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT</td>
          <td>MID-SIZE</td>
          <td>1.8</td>
          <td>4</td>
          <td>A6</td>
          <td>X</td>
          <td>9.9</td>
          <td>6.9</td>
          <td>8.6</td>
          <td>33</td>
          <td>198</td>
        </tr>
        <tr>
          <th>1044</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT</td>
          <td>MID-SIZE</td>
          <td>1.8</td>
          <td>4</td>
          <td>M5</td>
          <td>X</td>
          <td>10.0</td>
          <td>6.9</td>
          <td>8.6</td>
          <td>33</td>
          <td>198</td>
        </tr>
        <tr>
          <th>1045</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT</td>
          <td>MID-SIZE</td>
          <td>2.5</td>
          <td>5</td>
          <td>A6</td>
          <td>X</td>
          <td>11.0</td>
          <td>8.0</td>
          <td>9.7</td>
          <td>29</td>
          <td>223</td>
        </tr>
        <tr>
          <th>1046</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT</td>
          <td>MID-SIZE</td>
          <td>2.5</td>
          <td>5</td>
          <td>M5</td>
          <td>X</td>
          <td>11.4</td>
          <td>7.8</td>
          <td>9.8</td>
          <td>29</td>
          <td>225</td>
        </tr>
        <tr>
          <th>1047</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT</td>
          <td>MID-SIZE</td>
          <td>3.6</td>
          <td>6</td>
          <td>A6</td>
          <td>Z</td>
          <td>12.4</td>
          <td>8.8</td>
          <td>10.8</td>
          <td>26</td>
          <td>248</td>
        </tr>
        <tr>
          <th>1048</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT TDI CLEAN DIESEL</td>
          <td>MID-SIZE</td>
          <td>2.0</td>
          <td>4</td>
          <td>A6</td>
          <td>D</td>
          <td>8.1</td>
          <td>5.9</td>
          <td>7.1</td>
          <td>40</td>
          <td>192</td>
        </tr>
        <tr>
          <th>1049</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>PASSAT TDI CLEAN DIESEL</td>
          <td>MID-SIZE</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>D</td>
          <td>8.0</td>
          <td>5.4</td>
          <td>6.8</td>
          <td>42</td>
          <td>184</td>
        </tr>
        <tr>
          <th>1050</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>ROUTAN</td>
          <td>MINIVAN</td>
          <td>3.6</td>
          <td>6</td>
          <td>A6</td>
          <td>X</td>
          <td>14.2</td>
          <td>9.5</td>
          <td>12.1</td>
          <td>23</td>
          <td>278</td>
        </tr>
        <tr>
          <th>1051</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>TIGUAN</td>
          <td>SUV - SMALL</td>
          <td>2.0</td>
          <td>4</td>
          <td>A6</td>
          <td>Z</td>
          <td>11.7</td>
          <td>9.5</td>
          <td>10.7</td>
          <td>26</td>
          <td>246</td>
        </tr>
        <tr>
          <th>1052</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>TIGUAN</td>
          <td>SUV - SMALL</td>
          <td>2.0</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>13.6</td>
          <td>9.2</td>
          <td>11.6</td>
          <td>24</td>
          <td>267</td>
        </tr>
        <tr>
          <th>1053</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>TIGUAN 4MOTION</td>
          <td>SUV - SMALL</td>
          <td>2.0</td>
          <td>4</td>
          <td>A6</td>
          <td>Z</td>
          <td>11.7</td>
          <td>9.4</td>
          <td>10.7</td>
          <td>26</td>
          <td>246</td>
        </tr>
        <tr>
          <th>1054</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>TOUAREG</td>
          <td>SUV - STANDARD</td>
          <td>3.6</td>
          <td>6</td>
          <td>AS8</td>
          <td>Z</td>
          <td>13.8</td>
          <td>10.3</td>
          <td>12.2</td>
          <td>23</td>
          <td>281</td>
        </tr>
        <tr>
          <th>1055</th>
          <td>2014</td>
          <td>VOLKSWAGEN</td>
          <td>TOUAREG TDI CLEAN DIESEL</td>
          <td>SUV - STANDARD</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS8</td>
          <td>D</td>
          <td>12.3</td>
          <td>8.0</td>
          <td>10.4</td>
          <td>27</td>
          <td>281</td>
        </tr>
        <tr>
          <th>1056</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>S60</td>
          <td>COMPACT</td>
          <td>2.5</td>
          <td>5</td>
          <td>AS6</td>
          <td>X</td>
          <td>11.3</td>
          <td>7.8</td>
          <td>9.7</td>
          <td>29</td>
          <td>223</td>
        </tr>
        <tr>
          <th>1057</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>S60 AWD</td>
          <td>COMPACT</td>
          <td>2.5</td>
          <td>5</td>
          <td>AS6</td>
          <td>X</td>
          <td>11.6</td>
          <td>8.3</td>
          <td>10.1</td>
          <td>28</td>
          <td>232</td>
        </tr>
        <tr>
          <th>1058</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>S60 AWD</td>
          <td>COMPACT</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.2</td>
          <td>9.5</td>
          <td>11.5</td>
          <td>25</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1059</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>S80</td>
          <td>MID-SIZE</td>
          <td>3.2</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>11.9</td>
          <td>8.1</td>
          <td>10.2</td>
          <td>28</td>
          <td>235</td>
        </tr>
        <tr>
          <th>1060</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>S80 AWD</td>
          <td>MID-SIZE</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.2</td>
          <td>9.5</td>
          <td>11.5</td>
          <td>25</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1061</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC60</td>
          <td>SUV - SMALL</td>
          <td>3.2</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.0</td>
          <td>8.9</td>
          <td>11.2</td>
          <td>25</td>
          <td>258</td>
        </tr>
        <tr>
          <th>1062</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC60 AWD</td>
          <td>SUV - SMALL</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.4</td>
          <td>9.8</td>
          <td>11.8</td>
          <td>24</td>
          <td>271</td>
        </tr>
        <tr>
          <th>1063</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC60 AWD</td>
          <td>SUV - SMALL</td>
          <td>3.2</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.2</td>
          <td>9.5</td>
          <td>11.5</td>
          <td>25</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1064</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC70 AWD</td>
          <td>SUV - SMALL</td>
          <td>3.0</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>13.4</td>
          <td>9.8</td>
          <td>11.8</td>
          <td>24</td>
          <td>271</td>
        </tr>
        <tr>
          <th>1065</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC70 AWD</td>
          <td>SUV - SMALL</td>
          <td>3.2</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>12.9</td>
          <td>9.3</td>
          <td>11.3</td>
          <td>25</td>
          <td>260</td>
        </tr>
        <tr>
          <th>1066</th>
          <td>2014</td>
          <td>VOLVO</td>
          <td>XC90 AWD</td>
          <td>SUV - STANDARD</td>
          <td>3.2</td>
          <td>6</td>
          <td>AS6</td>
          <td>X</td>
          <td>14.9</td>
          <td>10.2</td>
          <td>12.8</td>
          <td>22</td>
          <td>294</td>
        </tr>
      </tbody>
    </table>
    <p>1067 rows × 13 columns</p>
    </div>



.. code:: ipython3

    dataframe.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>MODELYEAR</th>
          <th>MAKE</th>
          <th>MODEL</th>
          <th>VEHICLECLASS</th>
          <th>ENGINESIZE</th>
          <th>CYLINDERS</th>
          <th>TRANSMISSION</th>
          <th>FUELTYPE</th>
          <th>FUELCONSUMPTION_CITY</th>
          <th>FUELCONSUMPTION_HWY</th>
          <th>FUELCONSUMPTION_COMB</th>
          <th>FUELCONSUMPTION_COMB_MPG</th>
          <th>CO2EMISSIONS</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX</td>
          <td>COMPACT</td>
          <td>2.0</td>
          <td>4</td>
          <td>AS5</td>
          <td>Z</td>
          <td>9.9</td>
          <td>6.7</td>
          <td>8.5</td>
          <td>33</td>
          <td>196</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX</td>
          <td>COMPACT</td>
          <td>2.4</td>
          <td>4</td>
          <td>M6</td>
          <td>Z</td>
          <td>11.2</td>
          <td>7.7</td>
          <td>9.6</td>
          <td>29</td>
          <td>221</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>ILX HYBRID</td>
          <td>COMPACT</td>
          <td>1.5</td>
          <td>4</td>
          <td>AV7</td>
          <td>Z</td>
          <td>6.0</td>
          <td>5.8</td>
          <td>5.9</td>
          <td>48</td>
          <td>136</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>MDX 4WD</td>
          <td>SUV - SMALL</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>12.7</td>
          <td>9.1</td>
          <td>11.1</td>
          <td>25</td>
          <td>255</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2014</td>
          <td>ACURA</td>
          <td>RDX AWD</td>
          <td>SUV - SMALL</td>
          <td>3.5</td>
          <td>6</td>
          <td>AS6</td>
          <td>Z</td>
          <td>12.1</td>
          <td>8.7</td>
          <td>10.6</td>
          <td>27</td>
          <td>244</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df=dataframe

.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>MODELYEAR</th>
          <th>ENGINESIZE</th>
          <th>CYLINDERS</th>
          <th>FUELCONSUMPTION_CITY</th>
          <th>FUELCONSUMPTION_HWY</th>
          <th>FUELCONSUMPTION_COMB</th>
          <th>FUELCONSUMPTION_COMB_MPG</th>
          <th>CO2EMISSIONS</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>1067.0</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
          <td>1067.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>2014.0</td>
          <td>3.346298</td>
          <td>5.794752</td>
          <td>13.296532</td>
          <td>9.474602</td>
          <td>11.580881</td>
          <td>26.441425</td>
          <td>256.228679</td>
        </tr>
        <tr>
          <th>std</th>
          <td>0.0</td>
          <td>1.415895</td>
          <td>1.797447</td>
          <td>4.101253</td>
          <td>2.794510</td>
          <td>3.485595</td>
          <td>7.468702</td>
          <td>63.372304</td>
        </tr>
        <tr>
          <th>min</th>
          <td>2014.0</td>
          <td>1.000000</td>
          <td>3.000000</td>
          <td>4.600000</td>
          <td>4.900000</td>
          <td>4.700000</td>
          <td>11.000000</td>
          <td>108.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>2014.0</td>
          <td>2.000000</td>
          <td>4.000000</td>
          <td>10.250000</td>
          <td>7.500000</td>
          <td>9.000000</td>
          <td>21.000000</td>
          <td>207.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>2014.0</td>
          <td>3.400000</td>
          <td>6.000000</td>
          <td>12.600000</td>
          <td>8.800000</td>
          <td>10.900000</td>
          <td>26.000000</td>
          <td>251.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>2014.0</td>
          <td>4.300000</td>
          <td>8.000000</td>
          <td>15.550000</td>
          <td>10.850000</td>
          <td>13.350000</td>
          <td>31.000000</td>
          <td>294.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>2014.0</td>
          <td>8.400000</td>
          <td>12.000000</td>
          <td>30.200000</td>
          <td>20.500000</td>
          <td>25.800000</td>
          <td>60.000000</td>
          <td>488.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    cdf=df[["ENGINESIZE",'CYLINDERS','FUELCONSUMPTION_COMB','CO2EMISSIONS']]
    cdf




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>ENGINESIZE</th>
          <th>CYLINDERS</th>
          <th>FUELCONSUMPTION_COMB</th>
          <th>CO2EMISSIONS</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2.0</td>
          <td>4</td>
          <td>8.5</td>
          <td>196</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2.4</td>
          <td>4</td>
          <td>9.6</td>
          <td>221</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1.5</td>
          <td>4</td>
          <td>5.9</td>
          <td>136</td>
        </tr>
        <tr>
          <th>3</th>
          <td>3.5</td>
          <td>6</td>
          <td>11.1</td>
          <td>255</td>
        </tr>
        <tr>
          <th>4</th>
          <td>3.5</td>
          <td>6</td>
          <td>10.6</td>
          <td>244</td>
        </tr>
        <tr>
          <th>5</th>
          <td>3.5</td>
          <td>6</td>
          <td>10.0</td>
          <td>230</td>
        </tr>
        <tr>
          <th>6</th>
          <td>3.5</td>
          <td>6</td>
          <td>10.1</td>
          <td>232</td>
        </tr>
        <tr>
          <th>7</th>
          <td>3.7</td>
          <td>6</td>
          <td>11.1</td>
          <td>255</td>
        </tr>
        <tr>
          <th>8</th>
          <td>3.7</td>
          <td>6</td>
          <td>11.6</td>
          <td>267</td>
        </tr>
        <tr>
          <th>9</th>
          <td>2.4</td>
          <td>4</td>
          <td>9.2</td>
          <td>212</td>
        </tr>
        <tr>
          <th>10</th>
          <td>2.4</td>
          <td>4</td>
          <td>9.8</td>
          <td>225</td>
        </tr>
        <tr>
          <th>11</th>
          <td>3.5</td>
          <td>6</td>
          <td>10.4</td>
          <td>239</td>
        </tr>
        <tr>
          <th>12</th>
          <td>5.9</td>
          <td>12</td>
          <td>15.6</td>
          <td>359</td>
        </tr>
        <tr>
          <th>13</th>
          <td>5.9</td>
          <td>12</td>
          <td>15.6</td>
          <td>359</td>
        </tr>
        <tr>
          <th>14</th>
          <td>4.7</td>
          <td>8</td>
          <td>14.7</td>
          <td>338</td>
        </tr>
        <tr>
          <th>15</th>
          <td>4.7</td>
          <td>8</td>
          <td>15.4</td>
          <td>354</td>
        </tr>
        <tr>
          <th>16</th>
          <td>4.7</td>
          <td>8</td>
          <td>14.7</td>
          <td>338</td>
        </tr>
        <tr>
          <th>17</th>
          <td>4.7</td>
          <td>8</td>
          <td>15.4</td>
          <td>354</td>
        </tr>
        <tr>
          <th>18</th>
          <td>5.9</td>
          <td>12</td>
          <td>15.6</td>
          <td>359</td>
        </tr>
        <tr>
          <th>19</th>
          <td>2.0</td>
          <td>4</td>
          <td>8.8</td>
          <td>202</td>
        </tr>
        <tr>
          <th>20</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.0</td>
          <td>230</td>
        </tr>
        <tr>
          <th>21</th>
          <td>2.0</td>
          <td>4</td>
          <td>9.3</td>
          <td>214</td>
        </tr>
        <tr>
          <th>22</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.0</td>
          <td>230</td>
        </tr>
        <tr>
          <th>23</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.0</td>
          <td>230</td>
        </tr>
        <tr>
          <th>24</th>
          <td>2.0</td>
          <td>4</td>
          <td>9.3</td>
          <td>214</td>
        </tr>
        <tr>
          <th>25</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.2</td>
          <td>235</td>
        </tr>
        <tr>
          <th>26</th>
          <td>3.0</td>
          <td>6</td>
          <td>10.9</td>
          <td>251</td>
        </tr>
        <tr>
          <th>27</th>
          <td>3.0</td>
          <td>6</td>
          <td>8.3</td>
          <td>224</td>
        </tr>
        <tr>
          <th>28</th>
          <td>3.0</td>
          <td>6</td>
          <td>11.2</td>
          <td>258</td>
        </tr>
        <tr>
          <th>29</th>
          <td>3.0</td>
          <td>6</td>
          <td>8.3</td>
          <td>224</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>1037</th>
          <td>2.0</td>
          <td>4</td>
          <td>9.0</td>
          <td>207</td>
        </tr>
        <tr>
          <th>1038</th>
          <td>2.0</td>
          <td>4</td>
          <td>9.0</td>
          <td>207</td>
        </tr>
        <tr>
          <th>1039</th>
          <td>2.0</td>
          <td>4</td>
          <td>9.2</td>
          <td>212</td>
        </tr>
        <tr>
          <th>1040</th>
          <td>2.0</td>
          <td>4</td>
          <td>6.9</td>
          <td>186</td>
        </tr>
        <tr>
          <th>1041</th>
          <td>2.0</td>
          <td>4</td>
          <td>6.9</td>
          <td>186</td>
        </tr>
        <tr>
          <th>1042</th>
          <td>1.4</td>
          <td>4</td>
          <td>5.4</td>
          <td>124</td>
        </tr>
        <tr>
          <th>1043</th>
          <td>1.8</td>
          <td>4</td>
          <td>8.6</td>
          <td>198</td>
        </tr>
        <tr>
          <th>1044</th>
          <td>1.8</td>
          <td>4</td>
          <td>8.6</td>
          <td>198</td>
        </tr>
        <tr>
          <th>1045</th>
          <td>2.5</td>
          <td>5</td>
          <td>9.7</td>
          <td>223</td>
        </tr>
        <tr>
          <th>1046</th>
          <td>2.5</td>
          <td>5</td>
          <td>9.8</td>
          <td>225</td>
        </tr>
        <tr>
          <th>1047</th>
          <td>3.6</td>
          <td>6</td>
          <td>10.8</td>
          <td>248</td>
        </tr>
        <tr>
          <th>1048</th>
          <td>2.0</td>
          <td>4</td>
          <td>7.1</td>
          <td>192</td>
        </tr>
        <tr>
          <th>1049</th>
          <td>2.0</td>
          <td>4</td>
          <td>6.8</td>
          <td>184</td>
        </tr>
        <tr>
          <th>1050</th>
          <td>3.6</td>
          <td>6</td>
          <td>12.1</td>
          <td>278</td>
        </tr>
        <tr>
          <th>1051</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.7</td>
          <td>246</td>
        </tr>
        <tr>
          <th>1052</th>
          <td>2.0</td>
          <td>4</td>
          <td>11.6</td>
          <td>267</td>
        </tr>
        <tr>
          <th>1053</th>
          <td>2.0</td>
          <td>4</td>
          <td>10.7</td>
          <td>246</td>
        </tr>
        <tr>
          <th>1054</th>
          <td>3.6</td>
          <td>6</td>
          <td>12.2</td>
          <td>281</td>
        </tr>
        <tr>
          <th>1055</th>
          <td>3.0</td>
          <td>6</td>
          <td>10.4</td>
          <td>281</td>
        </tr>
        <tr>
          <th>1056</th>
          <td>2.5</td>
          <td>5</td>
          <td>9.7</td>
          <td>223</td>
        </tr>
        <tr>
          <th>1057</th>
          <td>2.5</td>
          <td>5</td>
          <td>10.1</td>
          <td>232</td>
        </tr>
        <tr>
          <th>1058</th>
          <td>3.0</td>
          <td>6</td>
          <td>11.5</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1059</th>
          <td>3.2</td>
          <td>6</td>
          <td>10.2</td>
          <td>235</td>
        </tr>
        <tr>
          <th>1060</th>
          <td>3.0</td>
          <td>6</td>
          <td>11.5</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1061</th>
          <td>3.2</td>
          <td>6</td>
          <td>11.2</td>
          <td>258</td>
        </tr>
        <tr>
          <th>1062</th>
          <td>3.0</td>
          <td>6</td>
          <td>11.8</td>
          <td>271</td>
        </tr>
        <tr>
          <th>1063</th>
          <td>3.2</td>
          <td>6</td>
          <td>11.5</td>
          <td>264</td>
        </tr>
        <tr>
          <th>1064</th>
          <td>3.0</td>
          <td>6</td>
          <td>11.8</td>
          <td>271</td>
        </tr>
        <tr>
          <th>1065</th>
          <td>3.2</td>
          <td>6</td>
          <td>11.3</td>
          <td>260</td>
        </tr>
        <tr>
          <th>1066</th>
          <td>3.2</td>
          <td>6</td>
          <td>12.8</td>
          <td>294</td>
        </tr>
      </tbody>
    </table>
    <p>1067 rows × 4 columns</p>
    </div>



.. code:: ipython3

    # Analysing every histogram which show how number of particular value show  
    new_cdf=cdf[['CYLINDERS','ENGINESIZE','CO2EMISSIONS','FUELCONSUMPTION_COMB']]
    new_cdf.hist()
    plt.show()



.. image:: output_7_0.png


.. code:: ipython3

    plt.scatter(cdf.FUELCONSUMPTION_COMB,cdf.CO2EMISSIONS, color='blue')
    plt.xlabel('Fuel_consumption')
    plt.ylabel('CO2_emission')
    plt.show()



.. image:: output_8_0.png


.. code:: ipython3

    #plotting veriation in engine and co2_emission
    plt.scatter(cdf.ENGINESIZE,cdf.CO2EMISSIONS, color='red')
    plt.xlabel('Engine_size')
    plt.ylabel('CO2 emission')
    plt.show()
    
    
    



.. image:: output_9_0.png


.. code:: ipython3

    # now we will check another variation 
    plt.scatter(cdf.CYLINDERS, cdf.CO2EMISSIONS,color='blue')
    plt.xlabel('Cylinders')
    plt.ylabel('Co2_emission')
    
    
    




.. parsed-literal::

    Text(0,0.5,'Co2_emission')




.. image:: output_10_1.png


.. code:: ipython3

    rand=np.random.rand(len(df))<.8

.. code:: ipython3

    train=cdf[rand]
    test=cdf[~rand]

.. code:: ipython3

    #now we will plt it using traing data
    plt.scatter(train.ENGINESIZE,train.CO2EMISSIONS,color='blue')
    plt.xlabel('ENGINE_SIZE')
    plt.ylabel('CO2Emission')
    plt.show()
    # we can see it is simple linear regression look like



.. image:: output_13_0.png


.. code:: ipython3

    # now We will make our model
    from sklearn.linear_model import LinearRegression
    regressor=LinearRegression()
    train_x=np.asanyarray(train[['ENGINESIZE']])
    train_y=np.asanyarray(train[['CO2EMISSIONS']])
    test_x=np.asanyarray(test[['ENGINESIZE']])
    test_y=np.asanyarray(test[['CO2EMISSIONS']])
    regressor.fit(train_x,train_y)
    




.. parsed-literal::

    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=False)



.. code:: ipython3

    # Now we will print intercept and slot coneffecint
    print(regressor.intercept_,regressor.coef_)


.. parsed-literal::

    [125.58691718] [[38.83320454]]
    

.. code:: ipython3

    #Coefficient and Intercept in the simple linear regression, are the parameters of the fit line.
    # Now we will plot two graph
    # one for acutal values and another for predict values
    # for acutal values
    plt.scatter(train.ENGINESIZE,train.CO2EMISSIONS,color='blue')
    y_pred=regressor.predict(test[['ENGINESIZE']])
    plt.plot(test.ENGINESIZE,regressor.predict(test[['ENGINESIZE']]),color='green')
    plt.show()



.. image:: output_16_0.png


.. code:: ipython3

    #Second method using intercept and coeff
    plt.scatter(train.ENGINESIZE,train.CO2EMISSIONS,color='blue')
    plt.plot(train_x,regressor.coef_[0][0] * train_x+regressor.intercept_,'-r')
    plt.xlabel('EngineSize')
    plt.ylabel('Co2emission')




.. parsed-literal::

    Text(0,0.5,'Co2emission')




.. image:: output_17_1.png


.. code:: ipython3

    from sklearn.metrics import confusion_matrix
    cf=confusion_matrix(test.CO2EMISSIONS,y_pred)
    


::


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-90-d983b898746c> in <module>()
          1 from sklearn.metrics import confusion_matrix
    ----> 2 cf=confusion_matrix(test.CO2EMISSIONS,y_pred)
          3 
          4 
          5 
    

    ~\Anaconda3\lib\site-packages\sklearn\metrics\classification.py in confusion_matrix(y_true, y_pred, labels, sample_weight)
        248 
        249     """
    --> 250     y_type, y_true, y_pred = _check_targets(y_true, y_pred)
        251     if y_type not in ("binary", "multiclass"):
        252         raise ValueError("%s is not supported" % y_type)
    

    ~\Anaconda3\lib\site-packages\sklearn\metrics\classification.py in _check_targets(y_true, y_pred)
         79     if len(y_type) > 1:
         80         raise ValueError("Classification metrics can't handle a mix of {0} "
    ---> 81                          "and {1} targets".format(type_true, type_pred))
         82 
         83     # We can't have more than one value on y_type => The set is no more needed
    

    ValueError: Classification metrics can't handle a mix of multiclass and continuous targets

